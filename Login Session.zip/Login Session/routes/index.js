var express = require('express');

var app = express();

//const path = require('path');

var sess; // global session, NOT recommended

//..........GET DEvice & User Info ................
app.get('/hello',function(req,res) {
    sess = req.session;
    if(sess.email){
      res.send("Hi to "+req.device.type.toUpperCase()+" User"+' '+ sess.email);
      res.end('<a href='+'/logout'+'>Logout</a>');
    }else{
        res.write('<h1>Please login first.</h1>');
        res.end('<a href='+'/'+'>Login</a>');
    }
});
//..................END..............................

app.get('/',(req,res) => {
    sess = req.session;
    if(sess.email) {
        res.write('<h1>Welcome TO Home</h1>');
        res.end('<a href='+'/admin'+'>Admin</a>');
        // return res.redirect('/admin');
    }else{
        res.sendFile('index.html');
    }
});

app.post('/login',(req,res) => {
    sess = req.session;
    sess.email = req.body.email;
    // res.end('done');
    res.write('<h1>User Logedin Succesfully</h1>');
    res.end('<a href='+'/admin'+'>Admin</a>');
});

app.get('/admin',(req,res) => {
    sess = req.session;
    if(sess.email) {
      console.log(sess.email)
        res.write(`<h1>Hello ${sess.email} </h1><br>`);
        res.end('<a href='+'/hello'+'>User</a><br> <a href='+'/logout'+'>Logout</a>')
        // res.end('<a href='+'/logout'+'>Logout</a>');
    }
    else {
        res.write('<h1>Please login first.</h1>');
        res.end('<a href='+'/'+'>Login</a>');
    }
});

app.get('/logout',(req,res) => {
    req.session.destroy((err) => {
        if(err) {
            return console.log(err);
        }
        res.redirect('/');
    });

});

// app.get('/home',function(req,res){                    //....NOT working..
//     res.sendFile(path.join(__dirname+'/home.html'));
//   });

module.exports = app;