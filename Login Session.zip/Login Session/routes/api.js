var express = require('express');
//var path = require('path');

var app = express();

var sess  // Session Store working here..


//app.get('/', function(req, res){
    //  res.sendFile(path.join(__dirname+'/dashboard.html')); //....NOT Working
//})


module.exports = app;