var express = require('express');
var bodyParser = require('body-parser');
var session = require('express-session');
var device = require('express-device');

var app = express();


app.use(device.capture()); //.. Device Checker.....

app.use(session({secret: 'ssshhhhh',saveUninitialized: true,resave: true}));

app.use(bodyParser.json());      
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static(__dirname + '/views'));

var indexRoute = require('./routes');
var apiRoute = require('./routes/api');

app.use('/', indexRoute);
app.use('/api', apiRoute);

var PORT = process.env.PORT || 9000;

app.listen(PORT, function(err, res){
     console.log('Listen to Port ' +PORT);
});